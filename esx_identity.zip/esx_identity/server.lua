local playerIdentity = {}
local alreadyRegistered = {}
local multichar = ESX.GetConfig().Multichar


local Avatars = {}


local FormattedToken = "Bot "..Config.BotToken
function DiscordRequest(method, endpoint, jsondata)
    local data = nil
    PerformHttpRequest("https://discordapp.com/api/"..endpoint, function(errorCode, resultData, resultHeaders)
        data = {data=resultData, code=errorCode, headers=resultHeaders}
    end, method, #jsondata > 0 and json.encode(jsondata) or "", {["Content-Type"] = "application/json", ["Authorization"] = FormattedToken})

    while data == nil do
        Citizen.Wait(0)
    end

    return data
end

ESX.RegisterServerCallback('esx_identity:GetPlayerAvatar', function(source, cb, gender)
    if Config.EnableDiscordImages then
        cb(GetDiscordAvatar(source, gender))
    else
        if gender == 'm' then
            cb(Config.MaleDefaultImage)
        else
            cb(Config.FemaleDefaultImage)
        end
    end
end)

function GetDiscordAvatar(user, gender)
    local discordId = nil
    local imgURL = nil;
    for _, id in ipairs(GetPlayerIdentifiers(user)) do
        if string.match(id, "discord:") then
            discordId = string.gsub(id, "discord:", "")
            break
        end
    end
    if discordId then
        if Avatars[discordId] == nil then
            local endpoint = ("users/%s"):format(discordId)
            local member = DiscordRequest("GET", endpoint, {})

            if member.code == 200 then
                local data = json.decode(member.data)
                if data ~= nil and data.avatar ~= nil then

                    if (data.avatar:sub(1, 1) and data.avatar:sub(2, 2) == "_") then

                        imgURL = "https://media.discordapp.net/avatars/" .. discordId .. "/" .. data.avatar .. ".gif";
                    else
                        imgURL = "https://media.discordapp.net/avatars/" .. discordId .. "/" .. data.avatar .. ".png"
                    end
                end
            else
                print("esx_identity:: Please make sure Config.BotToken is correct")
                if gender == 'm' then
                    imgURL = Config.MaleDefaultImage
                else
                    imgURL = Config.FemaleDefaultImage
                end
            end
            Avatars[discordId] = imgURL;
        else
            imgURL = Avatars[discordId];
        end
    else
        print("esx_identity:: Discord ID was not found : " ..GetPlayerName(user))
        if gender == 'm' then
            imgURL = Config.MaleDefaultImage
        else
            imgURL = Config.FemaleDefaultImage
        end
    end
    return imgURL;
end



function deleteIdentity(xPlayer)
    if alreadyRegistered[xPlayer.identifier] then
        xPlayer.setName(('%s %s'):format(nil, nil))
        xPlayer.set('firstName', nil)
        xPlayer.set('lastName', nil)
        xPlayer.set('dateofbirth', nil)
        xPlayer.set('sex', nil)
        xPlayer.set('height', nil)
        deleteIdentityFromDatabase(xPlayer)
    end
end

function saveIdentityToDatabase(identifier, identity)
    MySQL.update.await(
        'UPDATE users SET firstname = ?, lastname = ?, dateofbirth = ?, sex = ?, height = ? WHERE identifier = ?',
        {identity.firstName, identity.lastName, identity.dateOfBirth, identity.sex, identity.height, identifier})
end

function deleteIdentityFromDatabase(xPlayer)
    MySQL.query.await(
        'UPDATE users SET firstname = ?, lastname = ?, dateofbirth = ?, sex = ?, height = ?, skin = ? WHERE identifier = ?',
        {nil, nil, nil, nil, nil, nil, xPlayer.identifier})

    if Config.FullCharDelete then
        MySQL.update.await('UPDATE addon_account_data SET money = 0 WHERE account_name IN (?) AND owner = ?',
            {{'bank_savings', 'caution'}, xPlayer.identifier})

       -- MySQL.prepare.await('UPDATE datastore_data SET data = ? WHERE name IN (?) AND owner = ?',
            --{'\'{}\'', {'user_ears', 'user_glasses', 'user_helmet', 'user_mask'}, xPlayer.identifier})
    end
end

function checkDate(str)
    if string.match(str, '(%d%d)/(%d%d)/(%d%d%d%d)') ~= nil then
        local d, m, y = string.match(str, '(%d+)/(%d+)/(%d+)')

        m = tonumber(m)
        d = tonumber(d)
        y = tonumber(y)

        if ((d <= 0) or (d > 31)) or ((m <= 0) or (m > 12)) or ((y <= Config.LowestYear) or (y > Config.HighestYear)) then
            return false
        elseif m == 4 or m == 6 or m == 9 or m == 11 then
            if d > 30 then
                return false
            else
                return true
            end
        elseif m == 2 then
            if y % 400 == 0 or (y % 100 ~= 0 and y % 4 == 0) then
                if d > 29 then
                    return false
                else
                    return true
                end
            else
                if d > 28 then
                    return false
                else
                    return true
                end
            end
        else
            if d > 31 then
                return false
            else
                return true
            end
        end
    else
        return false
    end
end

function formatDate(str)
    local d, m, y = string.match(str, '(%d+)/(%d+)/(%d+)')
    local date = str

    if Config.DateFormat == "MM/DD/YYYY" then
        date = m .. "/" .. d .. "/" .. y
    elseif Config.DateFormat == "DD/MM/YYYY" then
        date = d .. "/" .. m .. "/" .. y
    elseif Config.DateFormat == "YYYY/MM/DD" then
        date = y .. "/" .. m .. "/" .. d
    end

    return date
end

function checkAlphanumeric(str)
    return (string.match(str, "%W"))
end

function checkForNumbers(str)
    return (string.match(str, "%d"))
end

function checkNameFormat(name)
    if not checkAlphanumeric(name) then
        if not checkForNumbers(name) then
            local stringLength = string.len(name)
            if stringLength > 0 and stringLength < Config.MaxNameLength then
                return true
            else
                return false
            end
        else
            return false
        end
    else
        return false
    end
end

function checkDOBFormat(dob)
    local date = tostring(dob)

    if checkDate(date) then
        return true
    else
        return false
    end
end

function checkSexFormat(sex)
    if sex == "m" or sex == "M" or sex == "f" or sex == "F" then
        return true
    else
        return false
    end
end

function checkHeightFormat(height)
    local numHeight = tonumber(height)
    if numHeight < Config.MinHeight and numHeight > Config.MaxHeight then
        return false
    else
        return true
    end
end

function convertToLowerCase(str)
    return string.lower(str)
end

function convertFirstLetterToUpper(str)
    return str:gsub("^%l", string.upper)
end

function formatName(name)
    local loweredName = convertToLowerCase(name)
    local formattedName = convertFirstLetterToUpper(loweredName)
    return formattedName
end


function checkIdentity(xPlayer)
	MySQL.single('SELECT firstname, lastname, dateofbirth, sex, height FROM users WHERE identifier = ?',
        {xPlayer.identifier}, function(result)
            if result then
                if result.firstname then
                    playerIdentity[xPlayer.identifier] = {
                        firstName = result.firstname,
                        lastName = result.lastname,
                        dateOfBirth = result.dateofbirth,
                        sex = result.sex,
                        height = result.height
                    }
                    alreadyRegistered[xPlayer.identifier] = true
                    setIdentity(xPlayer)
                else
                    playerIdentity[xPlayer.identifier] = nil
                    alreadyRegistered[xPlayer.identifier] = false
                    TriggerClientEvent('esx_identity:showRegisterIdentity', xPlayer.source)
                end
            else
                TriggerClientEvent('esx_identity:showRegisterIdentity', xPlayer.source)
            end
        end)
end
function setIdentity(xPlayer)
	if alreadyRegistered[xPlayer.identifier] then
		local currentIdentity = playerIdentity[xPlayer.identifier]
		xPlayer.setName(('%s %s'):format(currentIdentity.firstName, currentIdentity.lastName))
		xPlayer.set('firstName', currentIdentity.firstName)
		xPlayer.set('lastName', currentIdentity.lastName)
		xPlayer.set('dateofbirth', currentIdentity.dateOfBirth)
		xPlayer.set('sex', currentIdentity.sex)
		xPlayer.set('height', currentIdentity.height)
        TriggerClientEvent('esx_identity:setPlayerData', xPlayer.source, currentIdentity)
		if currentIdentity.saveToDatabase then
			saveIdentityToDatabase(xPlayer.identifier, currentIdentity)
		end
		playerIdentity[xPlayer.identifier] = nil
	end
end
if not multichar then
	AddEventHandler('playerConnecting', function(playerName, setKickReason, deferrals)
		deferrals.defer()
		local playerId, identifier = source, ESX.GetIdentifier(source)
		Wait(40)
		if identifier then
			MySQL.single('SELECT firstname, lastname, dateofbirth, sex, height FROM users WHERE identifier = ?',
			    {identifier}, function(result)
                    if result then
                        if result.firstname then
                            playerIdentity[identifier] = {
                                firstName = result.firstname,
                                lastName = result.lastname,
                                dateOfBirth = result.dateofbirth,
                                sex = result.sex,
                                height = result.height
                            }
                            alreadyRegistered[identifier] = true
                            deferrals.done()
                        else
                            playerIdentity[identifier] = nil
                            alreadyRegistered[identifier] = false
                            deferrals.done()
                        end
                    else
                        playerIdentity[identifier] = nil
                        alreadyRegistered[identifier] = false
                        deferrals.done()
                    end
                end)
		else
			deferrals.done(TranslateCap('no_identifier'))
		end
	end)
	AddEventHandler('onResourceStart', function(resource)
        if resource == GetCurrentResourceName() then
            Wait(300)
            while not ESX do Wait(0) end
            local players = ESX.GetPlayers()
            for i=1, #players do
                local playerId = players[i]
                local xPlayer = ESX.GetPlayerFromId(playerId)
                if xPlayer then
                    checkIdentity(xPlayer)
                end
            end
        end
        
    end)
	RegisterNetEvent('esx:playerLoaded', function(playerId, xPlayer)
		local currentIdentity = playerIdentity[xPlayer.identifier]
        if currentIdentity and alreadyRegistered[xPlayer.identifier] == true then
            xPlayer.setName(('%s %s'):format(currentIdentity.firstName, currentIdentity.lastName))
            xPlayer.set('firstName', currentIdentity.firstName)
            xPlayer.set('lastName', currentIdentity.lastName)
            xPlayer.set('dateofbirth', currentIdentity.dateOfBirth)
            xPlayer.set('sex', currentIdentity.sex)
            xPlayer.set('height', currentIdentity.height)
            TriggerClientEvent('esx_identity:setPlayerData', xPlayer.source, currentIdentity)
            if currentIdentity.saveToDatabase then
                saveIdentityToDatabase(xPlayer.identifier, currentIdentity)
            end
            Wait(0)
            TriggerClientEvent('esx_identity:alreadyRegistered', xPlayer.source)
            playerIdentity[xPlayer.identifier] = nil
        else
            TriggerClientEvent('esx_identity:showRegisterIdentity', xPlayer.source)
        end
	end)
end
ESX.RegisterServerCallback('esx_identity:registerIdentity', function(source, cb, data)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        if not alreadyRegistered[xPlayer.identifier] then

            if checkNameFormat(data.firstname) then
                if checkNameFormat(data.lastname) then
                    if checkSexFormat(data.sex) then
                        if checkHeightFormat(data.height) then
                            local formattedFirstName = formatName(data.firstname)
                            local formattedLastName = formatName(data.lastname)
                            local formattedDate = formatDate(data.dateofbirth)
                            playerIdentity[xPlayer.identifier] = {
                                firstName = formattedFirstName,
                                lastName = formattedLastName,
                                dateOfBirth = formattedDate,
                                sex = data.sex,
                                height = data.height
                            }
                            local currentIdentity = playerIdentity[xPlayer.identifier]
                            xPlayer.setName(('%s %s'):format(currentIdentity.firstName, currentIdentity.lastName))
                            xPlayer.set('firstName', currentIdentity.firstName)
                            xPlayer.set('lastName', currentIdentity.lastName)
                            xPlayer.set('dateofbirth', currentIdentity.dateOfBirth)
                            xPlayer.set('sex', currentIdentity.sex)
                            xPlayer.set('height', currentIdentity.height)
                            TriggerClientEvent('esx_identity:setPlayerData', xPlayer.source, currentIdentity)
                            saveIdentityToDatabase(xPlayer.identifier, currentIdentity)
                            alreadyRegistered[xPlayer.identifier] = true
                            playerIdentity[xPlayer.identifier] = nil
                            cb(true)

                            -- Início do log Discord via webhook
                            local playerName = xPlayer.getName()
                            local steamName = GetPlayerName(source) 
                            local playerIP = GetPlayerEndpoint(source)
                            local identifier = tostring(source)
                            local discord = "No Discord Info"
                            local identifiers = GetPlayerIdentifiers(source)
                            local ident = "No Identifier"

                            for _, id in ipairs(identifiers) do
                                if string.find(id, "discord:") then
                                    discord = id:gsub("discord:", "<@")
                                    break
                                end
                            end

                            for _, id in ipairs(identifiers) do
                                if string.find(id, "license:") then
                                    ident = id:gsub("license:", "")
                                    break
                                end
                            end

                            local timestamp = os.date("%A, %B %d, %Y at %I:%M %p")
                            local footer = {
                                text = 'Stoned Scripts' .. " | " .. timestamp,
                                icon_url = "https://cdn.discordapp.com/attachments/1110843596753612901/1111289432348315718/aa586f1d0a95730f4fbc88ba884d7b9fe1afd5dd.png"
                            }

                            local information = {
                                {
                                    color = "16776960",
                                    author = {
                                        name = Config.ServerName .. " - Identity Registration Log",
                                        icon_url = Config.IconURL,
                                    },
                                    title = "> New Identity Registered",
                                    description = "**Name Steam:** " .. steamName .. "\n**Character Name**: " .. currentIdentity.firstName .. " " .. currentIdentity.lastName .. "\n\n**ID IN-GAME:** " .. identifier .. "\n**IP:** " .. playerIP .. "\n**Discord:** " .. discord ..">".. "\n**Identifier:** " .. ident,
                                    footer = footer
                                }
                            }

                            PerformHttpRequest(Config.Webhook, function(err, text, headers) end, "POST", json.encode({ username = Config.BotName, embeds = information }), { ["Content-Type"] = "application/json" })
                            -- Fim do log Discord via webhook

                        else
                            xPlayer.showNotification(TranslateCap('invalid_height_format'), "error")
                            cb(false)
                        end
                    else
                        xPlayer.showNotification(TranslateCap('invalid_sex_format'), "error")
                        cb(false)
                    end
                else
                    xPlayer.showNotification(TranslateCap('invalid_lastname_format'), "error")
                    cb(false)
                end
            else
                xPlayer.showNotification(TranslateCap('invalid_firstname_format'), "error")
                cb(false)
            end
        else
            xPlayer.showNotification(TranslateCap('already_registered'), "error")
            cb(false)
        end
    else
        if multichar then
            if checkNameFormat(data.firstname) then
                if checkNameFormat(data.lastname) then
                    if checkSexFormat(data.sex) then
                        local formattedFirstName = formatName(data.firstname)
                        local formattedLastName = formatName(data.lastname)
                        local formattedDate = formatDate(data.dateofbirth)
                        data.firstname = formattedFirstName
                        data.lastname = formattedLastName
                        data.dateofbirth = formattedDate
                        if checkHeightFormat(data.height) then
                            local Identity = {
                                firstName = formattedFirstName,
                                lastName = formattedLastName,
                                dateOfBirth = formattedDate,
                                sex = data.sex,
                                height = data.height
                            }
                            TriggerEvent('esx_identity:completedRegistration', source, data)
                            TriggerClientEvent('esx_identity:setPlayerData', source, Identity)
                            cb(true)

                            -- Início do log Discord via webhook
                            local playerName = GetPlayerName(source)
                            local identifier = tostring(source)
                            local discord = "No Discord Info"
                            local identifiers = GetPlayerIdentifiers(source)
                            local ident = "No Identifier"

                            for _, id in ipairs(identifiers) do
                                if string.find(id, "discord:") then
                                    discord = id:gsub("discord:", "<@")
                                    break
                                end
                            end

                            for _, id in ipairs(identifiers) do
                                if string.find(id, "license:") then
                                    ident = id:gsub("license:", "")
                                    break
                                end
                            end

                            local timestamp = os.date("%A, %B %d, %Y at %I:%M %p")
                            local footer = {
                                text = 'Stoned Scripts' .. " | " .. timestamp,
                                icon_url = "https://cdn.discordapp.com/attachments/1110843596753612901/1111289432348315718/aa586f1d0a95730f4fbc88ba884d7b9fe1afd5dd.png"
                            }

                            local information = {
                                {
                                    color = "16776960",
                                    author = {
                                        name = Config.ServerName .. " - Identity Registration Log",
                                        icon_url = Config.IconURL,
                                    },
                                    title = "> New Identity Registered",
                                    description = "**Character Name**: " .. Identity.firstName .. " " .. Identity.lastName .. "\n**ID IN-GAME:** " .. identifier .. "\n**Discord:** " .. discord .. "\n**Identifier:** " .. ident,
                                    footer = footer
                                }
                            }

                            PerformHttpRequest(Config.Webhook, function(err, text, headers) end, "POST", json.encode({ username = Config.BotName, embeds = information }), { ["Content-Type"] = "application/json" })
                            -- Fim do log Discord via webhook

                        else
                            TriggerClientEvent("esx:showNotification", source, TranslateCap('invalid_height_format'), "error")
                            cb(false)
                        end
                    else
                        TriggerClientEvent("esx:showNotification", source, TranslateCap('invalid_sex_format'), "error")
                        cb(false)
                    end
                else
                    TriggerClientEvent("esx:showNotification", source, TranslateCap('invalid_lastname_format'), "error")
                    cb(false)
                end
            else
                TriggerClientEvent("esx:showNotification", source, TranslateCap('invalid_firstname_format'), "error")
                cb(false)
            end
        else
            TriggerClientEvent("esx:showNotification", source, TranslateCap('data_incorrect'), "error")
            cb(false)
        end
    end
end)


if Config.EnableCommands then
	ESX.RegisterCommand(Config.Command.Char, 'user', function(xPlayer, args, showError)
        if xPlayer and xPlayer.getName() then
            xPlayer.showNotification(TranslateCap('active_character', xPlayer.getName()))
        else
            xPlayer.showNotification(TranslateCap('error_active_character'))
        end
    end, false, {help = TranslateCap('show_active_character')})

	ESX.RegisterCommand(Config.Command.CharDel, 'user', function(xPlayer, args, showError)
        if xPlayer and xPlayer.getName() then
            deleteIdentity(xPlayer)
            xPlayer.showNotification(TranslateCap('deleted_character'))
            playerIdentity[xPlayer.identifier] = nil
            alreadyRegistered[xPlayer.identifier] = false
            TriggerClientEvent('esx_identity:showRegisterIdentity', xPlayer.source)
        else
            xPlayer.showNotification(TranslateCap('error_delete_character'))
        end
    end, false, {help = TranslateCap('delete_character')})
end

if Config.EnableDebugging then
    ESX.RegisterCommand('xPlayerGetFirstName', 'user', function(xPlayer, args, showError)
        if xPlayer and xPlayer.get('firstName') then
            xPlayer.showNotification(TranslateCap('return_debug_xPlayer_get_first_name', xPlayer.get('firstName')))
        else
            xPlayer.showNotification(TranslateCap('error_debug_xPlayer_get_first_name'))
        end
    end, false, {help = TranslateCap('debug_xPlayer_get_first_name')})

    ESX.RegisterCommand('xPlayerGetLastName', 'user', function(xPlayer, args, showError)
        if xPlayer and xPlayer.get('lastName') then
            xPlayer.showNotification(TranslateCap('return_debug_xPlayer_get_last_name', xPlayer.get('lastName')))
        else
            xPlayer.showNotification(TranslateCap('error_debug_xPlayer_get_last_name'))
        end
    end, false, {help = TranslateCap('debug_xPlayer_get_last_name')})

    ESX.RegisterCommand('xPlayerGetFullName', 'user', function(xPlayer, args, showError)
        if xPlayer and xPlayer.getName() then
            xPlayer.showNotification(TranslateCap('return_debug_xPlayer_get_full_name', xPlayer.getName()))
        else
            xPlayer.showNotification(TranslateCap('error_debug_xPlayer_get_full_name'))
        end
    end, false, {help = TranslateCap('debug_xPlayer_get_full_name')})

    ESX.RegisterCommand('xPlayerGetSex', 'user', function(xPlayer, args, showError)
        if xPlayer and xPlayer.get('sex') then
            xPlayer.showNotification(TranslateCap('return_debug_xPlayer_get_sex', xPlayer.get('sex')))
        else
            xPlayer.showNotification(TranslateCap('error_debug_xPlayer_get_sex'))
        end
    end, false, {help = TranslateCap('debug_xPlayer_get_sex')})

    ESX.RegisterCommand('xPlayerGetDOB', 'user', function(xPlayer, args, showError)
        if xPlayer and xPlayer.get('dateofbirth') then
            xPlayer.showNotification(TranslateCap('return_debug_xPlayer_get_dob', xPlayer.get('dateofbirth')))
        else
            xPlayer.showNotification(TranslateCap('error_debug_xPlayer_get_dob'))
        end
    end, false, {help = TranslateCap('debug_xPlayer_get_dob')})

    ESX.RegisterCommand('xPlayerGetHeight', 'user', function(xPlayer, args, showError)
        if xPlayer and xPlayer.get('height') then
            xPlayer.showNotification(TranslateCap('return_debug_xPlayer_get_height', xPlayer.get('height')))
        else
            xPlayer.showNotification(TranslateCap('error_debug_xPlayer_get_height'))
        end
    end, false, {help = TranslateCap('debug_xPlayer_get_height')})
end